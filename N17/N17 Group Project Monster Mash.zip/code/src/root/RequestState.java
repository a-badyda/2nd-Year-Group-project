package root;

public enum RequestState {
ACCEPTED,
VIEWING,
PENDING,
DECLINED
}
