package root;

public enum Breed {
SLIME,
BEAST,
DEMON,
SERPENT,
DRAGON,
GHOST
}
