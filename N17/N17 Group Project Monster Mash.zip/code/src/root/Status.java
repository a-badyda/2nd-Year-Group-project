package root;

public enum Status {
NORMAL,
SICK,
DEAD,
HAPPY
}
