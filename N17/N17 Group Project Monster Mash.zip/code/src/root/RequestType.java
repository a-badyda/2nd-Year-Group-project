package root;

public enum RequestType {
	BATTLE,
	BREED,
	FRIEND,
	battle_results,
	battle_request,
	friend_accepted,
	friend_request,
	breed_result,
	buy_result
}
