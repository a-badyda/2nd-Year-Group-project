
The Second Year Group Project 2012-2013  : Monster Mash

The website is accessible through http://www.monstermashgame.co.uk/login.html

The Structure of the project: 

All of the final code is contained in the folder called "code"
	Within the "code" folder:
	The "Web Content" contains the HTML, CSS and JavaScript.
	The "doc" folder contains the Javadoc for the Java files.
	The "src" folder contains all the Java source files.
		The "JUnit" folder contains all the JUnit tests.
		The "root" contains the root files. 

